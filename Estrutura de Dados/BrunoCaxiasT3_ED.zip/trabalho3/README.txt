PARA COMPILAÇÃO DO CÓDIGO USE O SEGUINTE COMANDO:

gcc -Wall -pedantic -o BearingsFactory.exe main.c queues.c functions.c rolamentoMaq.c

O CÓDIGO FOI DEVIDAMENTE COMENTADO E QUALQUER FUNÇÃO QUE NÃO POSSUA NOMES AUTO EXPLICATIVOS
POSSUI AO MENOS UM COMENTARIO ACIMA DO CABEÇALHO DA MESMA FALANDO SUA FUNÇÃO.


AS FONTES DE ALGUNS PEDAÇOS DE CÓDIGO UTILIZADO FORAM AS SEGUINTES:

https://www.geeksforgeeks.org/linked-list-set-3-deleting-node/?ref=lbp
https://www.geeksforgeeks.org/queue-linked-list-implementation/?ref=lbp
https://www.geeksforgeeks.org/priority-queue-using-linked-list/
https://pt.stackoverflow.com/questions/450287/como-gerar-um-booleano-01-aleat%C3%B3riamente-dada-a-probabilidade-do-evento-verda



AUTHORS: BRUNO CARVALHO CAXIAS
