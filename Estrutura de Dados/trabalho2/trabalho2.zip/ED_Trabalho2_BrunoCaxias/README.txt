Para funcionamento do código os arquivos contendo o conteúdo das matrizes deve estar
presente na mesma pasta que o resto do código.

Comando para compilar: gcc -Wall -pedantic -o SparseMatrix.exe main.c matrix_func.c format_func.c

O formato de saida dos documentos segue o padrao dos documentos de teste:

Ordem
Linha;Coluna;Valor
Linha;Coluna;Valor
Linha;Coluna;Valor


